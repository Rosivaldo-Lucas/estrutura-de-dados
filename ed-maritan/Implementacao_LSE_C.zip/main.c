#include <stdio.h>
#include <stdlib.h>

#include "listaenc.h"

#define TRUE 1
#define FALSE 0

int main()
{
    tLista minhaLista;
    int i, dado;

    cria(&minhaLista);

    if (vazia(minhaLista) == FALSE){
        printf("Lista criada nao estava vazia!\n");
    }
    else{
        printf("Lista estava vazia!\n");
    }

    insere(&minhaLista, 1, 10);
    insere(&minhaLista, 2, 20);
    insere(&minhaLista, 3, 30);
    insere(&minhaLista, 4, 40);

    insere(&minhaLista, 3, 25);
    insere(&minhaLista, 5, 35);

    insere(&minhaLista, 1, 101);

    printf("Pos do elemento 10 = %d \n", buscaPorValor(minhaLista, 10));
    printf("Pos do elemento 30 = %d \n", buscaPorValor(minhaLista, 30));
    printf("Pos do elemento 40 = %d \n", buscaPorValor(minhaLista, 40));
    printf("Pos do elemento 11 = %d \n", buscaPorValor(minhaLista, 11));

    printf("\nLista antes da remocao \n");
    for (i = 1; i <= tamanho(minhaLista); i++){
        buscaPorPosicao(minhaLista, i, &dado);
        printf("%d-esimo elemento da lista = %d\n",
               i, dado);
    }


    remov(&minhaLista, 3, &dado);
    printf("\nDado removido = %d \n\n", dado);

    printf("Lista depois da remocao \n");
    for (i = 1; i <= tamanho(minhaLista); i++){
        buscaPorPosicao(minhaLista, i, &dado);
        printf("%d-esimo elemento da lista = %d\n",
               i, dado);
    }


    remov(&minhaLista, 1, &dado);
    printf("\nDado removido = %d \n\n", dado);

    printf("Lista depois da remocao \n");
    for (i = 1; i <= tamanho(minhaLista); i++){
        buscaPorPosicao(minhaLista, i, &dado);
        printf("%d-esimo elemento da lista = %d\n",
               i, dado);
    }

    remov(&minhaLista, 5, &dado);
    printf("\n*****Dado removido do fim da lista= %d \n\n", dado);

    printf("****Lista depois da remocao do ultimo elemento\n");
    for (i = 1; i <= tamanho(minhaLista); i++){
        buscaPorPosicao(minhaLista, i, &dado);
        printf("%d-esimo elemento da lista = %d\n",
               i, dado);
    }

    return 0;
}
